require 'faastruby-rpc/test_helper'
require 'faastruby/spec_helper'
include FaaStRuby::SpecHelper
